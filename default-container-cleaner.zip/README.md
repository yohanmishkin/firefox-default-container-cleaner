<p align="center">
  <img src="https://raw.githubusercontent.com/yohanmishkin/firefox-default-container-cleaner/master/icons/96.png" alt="Default Container Cleaner icon"/>
</p>
<h1 align="center">Default Container Cleaner</h1>
Moves all default container tabs into a new container generated with todays date as its name. This makes it easy to start each day with a fresh default container.

## Features for another day
- Error handling (what happens if you click twice in the same day?)
- Publish extension
- Tab count in container name
